package org.elsys.gates;

public abstract class NandFactory {

	public static Gate makeNotGate(Wire in, Wire out, String name) {
		CompositeGate notGate = new CompositeGate(name);
		
		notGate.addInput(in);
		notGate.addOutput(out);
		
		Gate nandGate = new NandGate(in, in, out);
		
		notGate.addGate(nandGate);
		
		return notGate;
	}

	public static Gate makeNotGate(Wire in, Wire out) {
		return makeNotGate(in, out, "NandNot");
	}

	public static Gate makeAndGate(Wire in1, Wire in2, Wire out, String name) {
		CompositeGate andGate = new CompositeGate(name);
		
		andGate.addInput(in1);
		andGate.addInput(in2);
		andGate.addOutput(out);
		
		Wire a = new Wire("andA");
		
		Gate nandGate = new NandGate(in1, in2, a);
		Gate notGate = makeNotGate(a, out);
		
		andGate.addGate(nandGate);
		andGate.addGate(notGate);
		
		return andGate;
	}

	public static Gate makeAndGate(Wire in1, Wire in2, Wire out) {
		return makeAndGate(in1, in2, out, "NandAnd");
	}

	public static Gate makeOrGate(Wire in1, Wire in2, Wire out, String name) {
		CompositeGate orGate = new CompositeGate(name);
		
		orGate.addInput(in1);
		orGate.addInput(in2);
		orGate.addOutput(out);
		
		Wire a = new Wire("orA");
		Wire b = new Wire("orB");
		
		Gate notGate1 = makeNotGate(in1, a);
		Gate notGate2 = makeNotGate(in2, b);
		Gate nandGate = new NandGate(a, b, out);
		
		orGate.addGate(notGate1);
		orGate.addGate(notGate2);
		orGate.addGate(nandGate);
		
		return orGate;
	}

	public static Gate makeOrGate(Wire in1, Wire in2, Wire out) {
		return makeOrGate(in1, in2, out, "NandOr");
	}

	public static Gate makeXorGate(Wire in1, Wire in2, Wire out, String name) {
		CompositeGate xorGate = new CompositeGate(name);
		
		xorGate.addInput(in1);
		xorGate.addInput(in2);
		xorGate.addOutput(out);
		
		Wire a = new Wire("xorA");
		Wire b = new Wire("xorB");
		
		Gate nandGate = new NandGate(in1, in2, a);
		Gate orGate = makeOrGate(in1, in2, b);
		Gate andGate = makeAndGate(a, b, out);
		
		xorGate.addGate(nandGate);
		xorGate.addGate(orGate);
		xorGate.addGate(andGate);
		
		return xorGate;
	}

	public static Gate makeXorGate(Wire in1, Wire in2, Wire out) {
		return makeXorGate(in1, in2, out, "NandXor");
	}

}
