package org.elsys.gates;

public abstract class GateFactory {

	public static Gate makeXorGate(Wire in1, Wire in2, Wire out, String name) {
		CompositeGate xorGate = new CompositeGate(name);

		xorGate.addInput(in1);
		xorGate.addInput(in2);
		xorGate.addOutput(out);

		Wire a = new Wire("xorA");
		Wire b = new Wire("xorB");
		Wire c = new Wire("xorC");

		Gate orGate = new OrGate(in1, in2, a);
		Gate andGate1 = new AndGate(in1, in2, b);
		Gate notGate = new InverterGate(b, c);
		Gate andGate2 = new AndGate(a, c, out);

		xorGate.addGate(orGate);
		xorGate.addGate(andGate1);
		xorGate.addGate(notGate);
		xorGate.addGate(andGate2);

		return xorGate;
	}

	public static Gate makeXorGate(Wire in1, Wire in2, Wire out) {
		return makeXorGate(in1, in2, out, "XorGate");
	}

	public static Gate makeHalfAdder(Wire a, Wire b, Wire s, Wire c, String name) {
		CompositeGate halfAdder = new CompositeGate(name);
		
		halfAdder.addInput(a);
		halfAdder.addInput(b);
		halfAdder.addOutput(s);
		halfAdder.addOutput(c);
		
		Gate xorGate = new XorGate(a, b, s);
		Gate andGate = new AndGate(a, b, c);
		
		halfAdder.addGate(xorGate);
		halfAdder.addGate(andGate);
		
		return halfAdder;
	}

	public static Gate makeHalfAdder(Wire a, Wire b, Wire s, Wire c) {
		return makeHalfAdder(a, b, s, c, "HalfAdder");
	}

	public static Gate makeFullAdder(Wire a, Wire b, Wire cIn, Wire sum, Wire cOut, String name) {
		CompositeGate fullAdder = new CompositeGate(name);
		
		fullAdder.addInput(a);
		fullAdder.addInput(b);
		fullAdder.addInput(cIn);
		fullAdder.addOutput(sum);
		fullAdder.addOutput(cOut);
		
		Wire s = new Wire("fullS");
		Wire c = new Wire("fullC");
		Wire d = new Wire("fullD");
		
		Gate halfAdder1 = makeHalfAdder(a, b, s, c);
		Gate halfAdder2 = makeHalfAdder(cIn, s, sum, d);
		Gate orGate = new OrGate(d, c, cOut);
		
		fullAdder.addGate(halfAdder1);
		fullAdder.addGate(halfAdder2);
		fullAdder.addGate(orGate);
		
		return fullAdder;
	}

	public static Gate makeFullAdder(Wire a, Wire b, Wire cIn, Wire sum, Wire cOut) {
		return makeFullAdder(a, b, cIn, sum, cOut, "FullAdder");
	}
	
	public static Gate makeRippleCarryAdder(Wire a[], Wire b[], Wire cIn, Wire sum[], Wire cOut) {
		assert a.length == b.length;
		assert a.length == sum.length;
		int N = a.length;
		
		CompositeGate rippleCarryAdder = new CompositeGate("RippleCarryOther");
		
		rippleCarryAdder.addInput(cIn);
		rippleCarryAdder.addOutput(cOut);
		
		for(int i = 0; i < N; i++)
		{
			rippleCarryAdder.addInput(a[i]);
			rippleCarryAdder.addInput(b[i]);
			rippleCarryAdder.addOutput(sum[i]);
			
			Gate fullAdder = makeFullAdder(a[i], b[i], cIn, sum[i], cOut);
			
			rippleCarryAdder.addGate(fullAdder);
			
			cIn = cOut;
		}
		
		return rippleCarryAdder;
	}
}
