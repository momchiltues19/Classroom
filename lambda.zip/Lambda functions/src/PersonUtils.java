
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PersonUtils {

	// FILTER BY AGE
	// sort by age
	// return list with first names
	
	public static List<String> filSort(List<Person> people)
	{
		List<Person> result = new ArrayList<>();
		for(Person person : people)
		{
			if(person.getAge() < 25 && person.getName().charAt(0) == 'S')
			{
				result.add(person);
			}
		}
		result.sort((p1, p2) -> p1.getAge() - p2.getAge());
		List<String> names = new ArrayList<>();
		for (Person person : result)
		{
			names.add(person.getName());
		}
		return names;
	}
	
	public static List<String> filStreSort(List<Person> people)
	{
		return people.stream()
			.filter(person -> person.getAge() < 25)
			.filter(person -> person.getName().charAt(0) == 'S')
			.sorted((p1, p2) -> p1.getAge() - p2.getAge())
			.map(person -> person.getName())
			.distinct()
			.collect(Collectors.toList());
	}

	public static List<Person> failingExample(List<Person> people)
	{
		Stream<Person> filt = people.stream()
				.filter(person -> person.getAge() < 25);
		List<Person> result = filt.collect(Collectors.toList());
		Integer sum = filt.map(person -> person.getAge())
						  .reduce(0, (a1, a2) -> a1 + a2);
		System.out.println("avg " + (sum/ result.size()));
		return result;
	}
	
	public static void main(String[] argv)
	{
		List<Person> people = Arrays.asList(
				new Person("Stefan", Gender.MALE, 18),
				new Person("Sandara", Gender.FEMALE, 20),
				new Person("Iva", Gender.FEMALE, 10),
				new Person("STP", Gender.FEMALE, 19),
				new Person("STP", Gender.OTHER, 12),
				new Person("Sora", Gender.MALE, 13),
				new Person("sand", Gender.OTHER, 3));
		
		System.out.println(filSort(people));
		System.out.println(filStreSort(people));
		//failingExample(people);
	}
}
