import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Person {
	
	private String name;
	private Gender gender;
	private int age;
	
	public Person(String name, Gender gender, int age) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public Gender getGender() {
		return gender;
	}
	public int getAge() {
		return age;
	}
	
	public static List<Person> filter(List<Person> people, Filter filter)
	{
		List<Person> result = new ArrayList<Person>();
		for(Person p: people)
		{
			if(filter.match(p))
			{
				result.add(p);
			}
		}
		return result;
	}
	
	public static void main(String[] argv)
	{
		List<Person> people = Arrays.asList(
				new Person("Ivanka", Gender.FEMALE, 18),
				new Person("Ivancho", Gender.MALE, 20),
				new Person("Iva", Gender.FEMALE, 40),
				new Person("IPv6", Gender.OTHER, 49),
				new Person("Ivan", Gender.MALE, 70));
		List<Person> under35 = filter(people, new Filter()
		{
			@Override
			public boolean match(Person p)
			{
				return p.getAge() < 35;
			}
		});
		
		//System.out.println(under35.size());
		
		List<Person> under50notMale = filter(people, new Filter()
		{
			@Override
			public boolean match(Person p)
			{
				return p.getAge() < 50 && p.getGender() != Gender.MALE;
			}
		});
		
		//System.out.println(under50notMale.size());
		
		people.sort((p1, p2) -> p1.getAge() - p2.getAge());
		
		people.forEach(p -> {System.out.println("age: " + p.getAge() + " name: " + p.getName());});
		
		//sort by name
	}
}
