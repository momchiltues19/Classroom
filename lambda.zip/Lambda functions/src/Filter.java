
public interface Filter {
	
	public boolean match(Person p);
}
