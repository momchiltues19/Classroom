package org.elsys.part1;

import java.util.Iterator;

public class Box extends BallContainer {

	private double capacity;
	
	public Box(double capacity) {
		this.capacity = capacity;
	}

	@Override
	public boolean add(Ball b) 
	{
		if(capacity <= this.getVolume())
		{
			throw new BallContainerException();
		}	
		else return container.add(b);
	}
	
	public Iterator<Ball> getBallsFromSmallest() {
		container.sort(Comparator<Ball>);
		Iterator<Ball> i = container.iterator();
		return i;
	}

}