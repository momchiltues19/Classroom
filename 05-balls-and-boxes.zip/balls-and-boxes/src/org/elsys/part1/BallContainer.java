package org.elsys.part1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BallContainer {

	protected List<Ball> container = new ArrayList<>();
	
	public BallContainer() {
	}

	public boolean add(Ball b) 
	{
		return container.add(b);
	}

	public boolean remove(Ball b) 
	{
		return container.remove(b);
	}


	public double getVolume() 
	{
		double volume = 0;
		for(Iterator<Ball> i = container.iterator(); i.hasNext();) {
		    Ball item = i.next();
		    volume += item.getVolume();
		}
		return volume;
	}

	public int size() 
	{	
		return container.size();
	}

	public void clear() 
	{
		container.clear();
	}

	public boolean contains(Ball b) 
	{
		return container.contains(b);
	}

}