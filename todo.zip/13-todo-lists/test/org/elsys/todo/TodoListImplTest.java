package org.elsys.todo;

import static org.junit.Assert.*;

import org.elsys.todo.impl.*;
import org.junit.Test;

public class TodoListImplTest {

	private TodoList todoList = TodoList.parse(
			"TODO    | Do OOP homework              | Low    | school, programming\r\n" + 
			"TODO    | Get 8 hours of sleep.        | Low    | health\r\n" + 
			"DOING   | Party hard.                  | Normal | social\r\n" + 
			"DONE    | Netflix and chill.           | Normal | tv shows\r\n" + 
			"TODO    | Find missing socks.          | Low    | meh\r\n" + 
			"");
	
	@Test
	public void testIsCompleted() 
	{
		assertEquals(false, todoList.isCompleted());
	}
	
	@Test
	public void testPercentageCompleted() 
	{
		assertEquals(new Double(0.20), todoList.completedPercentage());
	}
	
	@Test
	public void testStatusPercentage() 
	{
		assertEquals(new Double(0.60), todoList.statusPercentage(Status.TODO));
		assertEquals(new Double(0.20), todoList.statusPercentage(Status.DOING));
	}
	
	@Test
	public void testMatchingPercentage() 
	{
		assertEquals(new Double(0.60), todoList.matchingPercentage(new CriteriaImpl(Status.TODO, Priority.LOW, null)));
	}
	
	@Test
	public void testFilter()
	{
		assertEquals(2, todoList.filter(new CriteriaImpl(Status.TODO, null, null)));
	}
}
