package org.elsys.todo.impl;

import java.util.Arrays;

import org.elsys.todo.Criteria;
import org.elsys.todo.Priority;
import org.elsys.todo.Status;

public class CriteriaImpl implements Criteria {
	
	private Status status;
	private Priority priority;
	private String[] tags;
	
	public CriteriaImpl(Status status, Priority priority, String[] tags) {
		this.status = status;
		this.priority = priority;
		this.tags = tags;
	}

	@Override
	public Criteria and(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria or(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria xor(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria not() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((priority == null) ? 0 : priority.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + Arrays.hashCode(tags);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CriteriaImpl other = (CriteriaImpl) obj;
		if (priority != other.priority && (other.priority != null))
			return false;
		if (status != other.status && (other.status != null))
			return false;
		if (!Arrays.equals(tags, other.tags) &&(other.tags != null))
			return false;
		return true;
	}
	
	

}
