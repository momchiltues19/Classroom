package org.elsys.todo.impl;

import java.util.ArrayList;
import java.util.List;

import org.elsys.todo.Criteria;
import org.elsys.todo.Status;

public class StatusCriteria implements Criteria{

	Status status;
	private List<Status> condStatus = new ArrayList<>();
	
	public StatusCriteria(Status status) {
		this.status = status;
	}
	
	public StatusCriteria(List<Status> status) {
		this.condStatus = status;
	}

	public Status getStatus()
	{
		return status;
	}
	
	public List<Status> getCondStatus()
	{
		return condStatus;
	}

	@Override
	public Criteria and(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria or(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria not() {
		for(Status s : Status.values())
		{
			if(!s.equals(status))condStatus.add(s);
		}
		return new StatusCriteria(condStatus);
	}

}
