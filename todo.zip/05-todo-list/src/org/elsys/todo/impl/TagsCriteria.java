package org.elsys.todo.impl;

import java.util.List;

import org.elsys.todo.Criteria;

public class TagsCriteria implements Criteria{

	private List<String> tags;
	
	public TagsCriteria(List<String> tags) {
		this.tags = tags;
	} 

	public List<String> getTags()
	{
		return tags;
	}
	
	@Override
	public Criteria and(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria or(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria not() {
		return null;
	}

}
