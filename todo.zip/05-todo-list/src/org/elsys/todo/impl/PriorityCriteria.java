package org.elsys.todo.impl;

import java.util.ArrayList;
import java.util.List;

import org.elsys.todo.Criteria;
import org.elsys.todo.Priority;

public class PriorityCriteria implements Criteria{

	private Priority priority;
	private List<Priority> condPriority = new ArrayList<>();
	
	public PriorityCriteria(Priority priority) {
		this.priority = priority;
	}
	
	public PriorityCriteria(List<Priority> priorities) {
		this.condPriority = priorities;
	}

	public Priority getPriority()
	{
		return priority;
	}
	
	public List<Priority> getCondPriority()
	{
		return condPriority;
	}
	
	@Override
	public Criteria and(Criteria other) {
		condPriority.add(priority);
		condPriority.add(((PriorityCriteria) other).getPriority());
		return new PriorityCriteria(condPriority);
	}

	@Override
	public Criteria or(Criteria other) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Criteria not() {
		for(Priority p : Priority.values())
		{
			if(!p.equals(priority))condPriority.add(p);
		}
		return new PriorityCriteria(condPriority);
	}

}
