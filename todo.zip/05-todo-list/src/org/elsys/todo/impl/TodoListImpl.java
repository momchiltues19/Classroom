package org.elsys.todo.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.elsys.todo.Criteria;
import org.elsys.todo.Priority;
import org.elsys.todo.Status;
import org.elsys.todo.Task;
import org.elsys.todo.TodoList;

public class TodoListImpl implements TodoList{

	List<Task> tasks = new ArrayList<>();
	
	public TodoListImpl(String input)
	{
		String[] values = input.split("[|\r\n]+");
		for(int i = 0; i < values.length; i++)
		{
			tasks.add(new TaskImpl(values[i++].replaceAll(" ",""), values[i++], values[i++].replaceAll(" ",""), values[i]));
		}
	}
	
	public TodoListImpl(List<Task> tasks)
	{
		this.tasks = tasks;
	}
	
	@Override
	public Boolean isCompleted() {
		Boolean completion = true;
		for(Task t : tasks)
		{
			if(!t.getStatus().equals(Status.DONE))
			{
				completion = false;
				break;
			}
		}
		return completion;
	}

	@Override
	public Double percentageCompleted() {
		Double completion = 0.00;
		for(Task t : tasks)
		{
			if(t.getStatus().equals(Status.DONE))
			{
				completion++;
			}
		}
		System.out.println(completion/tasks.size());
		return completion/tasks.size();
	}

	@Override
	public List<Task> getTasks() {
		return tasks;
	}

	@Override
	public TodoList filter(Criteria criteria) {
		PriorityCriteria priorityCrit = new PriorityCriteria(Priority.LOW);
		StatusCriteria statusCrit = new StatusCriteria(Status.DONE);
		TagsCriteria tagsCrit = new TagsCriteria(Arrays.asList("school", "social"));
		TodoListImpl todo = new TodoListImpl(tasks); 
		if(criteria.getClass().equals(priorityCrit.getClass())) 
		{
			priorityCrit = (PriorityCriteria) criteria;
			if(priorityCrit.getCondPriority().size() == 0)
			{
				Priority priority = priorityCrit.getPriority();
				todo = new TodoListImpl(tasks.stream()
						.filter(task -> task.getPriority().equals(priority))
						.collect(Collectors.toList())
						);
			}
			else
			{
				List<Priority> priorities = priorityCrit.getCondPriority();
				todo = new TodoListImpl(tasks.stream()
						.filter(task -> 
						{ 
							boolean flag = false;
							for(Priority p : priorities)
							{
								if(task.getPriority().equals(p))
								{
									flag = true;
									break;
								}
							}
							return flag;
						})
						.collect(Collectors.toList())
						);
			}
		} 
		else if(criteria.getClass().equals(statusCrit.getClass())) 
		{
			statusCrit = (StatusCriteria) criteria;
			if(statusCrit.getCondStatus().size() == 0)
			{
				Status status = statusCrit.getStatus();
				todo = new TodoListImpl(tasks.stream()
						.filter(task -> task.getStatus().equals(status))
						.collect(Collectors.toList())
						);
			}
			else
			{
				List<Status> status = statusCrit.getCondStatus();
				todo = new TodoListImpl(tasks.stream()
						.filter(task -> 
						{ 
							boolean flag = false;
							for(Status s : status)
							{
								if(task.getStatus().equals(s))
								{
									flag = true;
									//break;
								}
							}
							return flag;
						})
						.collect(Collectors.toList())
						);
			}
		} 
		else if(criteria.getClass().equals(tagsCrit.getClass()))
		{
			tagsCrit = (TagsCriteria) criteria;
			List<String> tags = tagsCrit.getTags();
			todo = new TodoListImpl(tasks.stream()
					.filter(task -> {
						boolean flag = false;
						for(int i = 0; i < task.getTags().length; i++)
						{
							for(String s : tags)
							{
								if(s.equals(task.getTags()[i]))
								{
									flag = true;
									break;
								}
							}
						}
						return flag;
					})
					.collect(Collectors.toList())
					);
		}
		return todo;
	}

	@Override
	public TodoList join(TodoList other) {
		List<Task> joined = tasks;
		for(Task t : other.getTasks())
		{
			joined.add(t);
		}
		return new TodoListImpl(joined);
	}

}
