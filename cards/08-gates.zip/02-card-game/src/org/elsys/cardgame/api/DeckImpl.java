package org.elsys.cardgame.api;

import java.util.ArrayList;
import java.util.List;

public class DeckImpl implements Deck {

	private List<Card> deck = new ArrayList<>();
	private int handsize;
	private List<Rank> ranking;
	
	@Override
	public List<Card> getCards() {
		return deck;
	}

	@Override
	public int size() {
		return deck.size();
	}

	@Override
	public int handSize() {
		return handsize;
	}

	@Override
	public Card drawTopCard() {
		return deck.remove(0);
	}

	@Override
	public Card topCard() {
		return deck.get(0);
	}

	@Override
	public Card drawBottomCard() {
		return deck.remove(size());
	}

	@Override
	public Card bottomCard() {
		return deck.get(size());
	}

	@Override
	public Hand deal() {
		List<Card> temp = new ArrayList<>();
		for(int i = 0; i < handsize; i++)
		{
			temp.add(drawTopCard());
		}
		return new HandImpl(temp);
	}

	@Override
	public void sort() {
		//deck.sort((card1, card2) -> card1 > card2);
	}

	@Override
	public void shuffle() {

	}

}
