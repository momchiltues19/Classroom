package org.elsys.cardgame.factory;

import org.elsys.cardgame.api.Deck;

public class DeckFactory {

	public static Deck defaultWarDeck() {
		// TODO
		return null;
	}

	public static Deck defaultSantaseDeck() {
		// TODO
		return null;
	}

	public static Deck defaultBeloteDeck() {
		// TODO
		return null;
	}
}
